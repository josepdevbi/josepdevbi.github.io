//let nombre = prompt("cual es tu nombre: ")
//let apellido = prompt("cual es tu apellido: ")
//let edad = prompt("cual es tu edad: ")
// alert("hola: " + nombre + " su Apellido es : " + apellido + " y tiene: " + edad + " años");

//const PI = 3-141516
//PI= 4
//console.log(PI)

// let mensaje = "Hola, mundo";
// console.log(typeof(mensaje));
// let cantidad = 42;
// console.log(typeof(cantidad))
// let esVerdadero = true;
// let valorNulo = null;
// let valorIndefinido;
// console.log(typeof(valorIndefinido));

// let numeroA = prompt("digite numero: ")
// let numeroB = prompt("digite numero: ")
// let producto = numeroA*numeroB
// alert("El Producto es: "+ producto)

// let x = 10;
// console.log(x)
// x += 5; // x = 15
// console.log(x)
// x *= 2; // x = 30
// x++;
// console.log(x)

function saludar() {

alert("Hola a todos");

}

saludar();

