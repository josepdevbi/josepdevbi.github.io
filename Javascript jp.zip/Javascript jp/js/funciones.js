// function saludar() {
//     const inputnumero1 = document.getElementById("numero1")
//     console.log(inputnumero1.value)
    
//     const inputnumero2 = document.getElementById("numero2")
//     console.log(inputnumero2.value);
//  }


function saludar() {
    const titulo = document.getElementById("titulo1")
    titulo.textContent = "NUEVA PRACTICA JS"
        
    const parrafo = document.getElementById("parrafo1")
    parrafo.textContent = "esto es una practica de java script"
     }

function cambiardiv() {

const contenido = document.getElementById("contenido")
contenido.innerHTML = '<h1>titulo con html</h1><form> <title> HOLA JP </title></form><p>parrafo con innerhtml</p>'
contenido.style.backgroundColor="#fff345"
}

function agregarelemento() {
    const nuevoDiv = document.createElement('div');
    nuevoDiv.textContent = 'Soy un nuevo DIV';
    document.body.appendChild(nuevoDiv);

}


// saludar("Ana");  // Imprime "¡Hola, Ana!"

//let numeroA = prompt("digite numero: ");
// let numeroB = prompt("digite numero: ");





// function sumar(a,b) {


// return a*b;
// }

// let resultado = sumar(inputnumero1,inputnumero2);
// alert("El resultado es: " + resultado)

